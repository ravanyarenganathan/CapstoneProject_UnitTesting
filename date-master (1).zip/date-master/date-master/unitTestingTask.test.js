const dateFormatter = require("./unitTestingTask");

describe("dateFormatter", () => {
  beforeAll(() => {
    dateFormatter.lang("en");
  });

  const sampleDate = new Date("2025-06-07T05:09:03.07Z");

  test("should correctly format full year", () => {
    expect(dateFormatter("YYYY", sampleDate)).toBe("2025");
  });

  test("should correctly format short year", () => {
    expect(dateFormatter("YY", sampleDate)).toBe("25");
  });

  test("should correctly format month in full name", () => {
    expect(dateFormatter("MMMM", sampleDate)).toBe("June");
  });

  test("should correctly format month in short name", () => {
    expect(dateFormatter("MMM", sampleDate)).toBe("Jun");
  });

  test("should correctly format numeric month with zero", () => {
    expect(dateFormatter("MM", sampleDate)).toBe("06");
  });

  test("should correctly format numeric month without zero", () => {
    expect(dateFormatter("M", sampleDate)).toBe("6");
  });

  test("should format full weekday name", () => {
    expect(dateFormatter("DDD", sampleDate)).toBe("Saturday");
  });

  test("should format abbreviated weekday name", () => {
    expect(dateFormatter("DD", sampleDate)).toBe("Sat");
  });

  test("should format shortest weekday name", () => {
    expect(dateFormatter("D", sampleDate)).toBe("Sa");
  });

  test("should format date with leading zero", () => {
    expect(dateFormatter("dd", sampleDate)).toBe("07");
  });

  test("should format date without leading zero", () => {
    expect(dateFormatter("d", sampleDate)).toBe("7");
  });

  test("should format hour with leading zero", () => {
    expect(dateFormatter("HH", sampleDate)).toBe("05");
  });

  test("should format hour without leading zero", () => {
    expect(dateFormatter("H", sampleDate)).toBe("5");
  });

  test("should format minutes with leading zero", () => {
    expect(dateFormatter("mm", sampleDate)).toBe("09");
  });

  test("should format minutes without leading zero", () => {
    expect(dateFormatter("m", sampleDate)).toBe("9");
  });

  test("should format seconds with leading zero", () => {
    expect(dateFormatter("ss", sampleDate)).toBe("03");
  });

  test("should format seconds without leading zero", () => {
    expect(dateFormatter("s", sampleDate)).toBe("3");
  });

  test("should format AM/PM uppercase", () => {
    expect(dateFormatter("A", sampleDate)).toBe("AM");
  });

  test("should format am/pm lowercase", () => {
    expect(dateFormatter("a", sampleDate)).toBe("am");
  });

  test("should handle Unix timestamp inputs", () => {
    expect(dateFormatter("YYYY", 1750136943456)).toBe("2025");
  });

  test("should handle ISO date string inputs", () => {
    expect(dateFormatter("YYYY", "2025-06-17T05:09:03.456Z")).toBe("2025");
  });

  test("should handle custom formats correctly", () => {
    dateFormatter.register("customFormat", "YYYY/MM/dd");
    expect(dateFormatter("customFormat", sampleDate)).toBe("2025/06/07");
  });

  test("should throw TypeError for invalid format type", () => {
    expect(() => dateFormatter(123)).toThrow(TypeError);
  });

  test("should throw TypeError for invalid date type", () => {
    expect(() => dateFormatter("YYYY", {})).toThrow(TypeError);
  });

  test("should allow language switching", () => {
    expect(dateFormatter.lang()).toBe("en");
    dateFormatter.lang("fr", {
      months: ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"],
      meridiem: (hour) => (hour > 11 ? "PM" : "AM"),
    });
    expect(dateFormatter.lang()).toBe("fr");
    dateFormatter.lang("en");
  });
});
